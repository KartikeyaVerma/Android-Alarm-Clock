package com.example.alarmclock.quote;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "quote_table")
public class Quote_saved {

    @PrimaryKey(autoGenerate = true)
    private int id;

    private String quote;

    public Quote_saved(String quote) {
        this.quote = quote;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public String getQuote() {
        return quote;
    }
}
