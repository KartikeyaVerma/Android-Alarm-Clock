package com.example.alarmclock.alarm;


import android.content.Context;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;


@Database(entities = {alarm_time.class}, version = 1)
public abstract class AlarmDatabase extends RoomDatabase {

    private static AlarmDatabase instance ;

    public abstract alarm_timeDao alarmTimeDao();

    public static synchronized AlarmDatabase getInstance(Context context){
        if (instance==null){
            instance = Room.databaseBuilder(context.getApplicationContext(),
                    AlarmDatabase.class , "alarm_database")
                    .fallbackToDestructiveMigration()
                    .addCallback(roomCallback)
                    .build();
        }
        return instance ;
    }

    private static RoomDatabase.Callback roomCallback = new RoomDatabase.Callback(){
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
            new PopulateDbAsyncTask(instance).execute();
        }
    };

    private static class PopulateDbAsyncTask extends AsyncTask<Void , Void , Void > {
        private alarm_timeDao alarmTimeDao;

        private PopulateDbAsyncTask(AlarmDatabase db){
            alarmTimeDao = db.alarmTimeDao();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            alarmTimeDao.insert(new alarm_time(8 , 10 , 1111100 , false));
            alarmTimeDao.insert(new alarm_time(9 , 10 , 1111100 , false));
            alarmTimeDao.insert(new alarm_time(10 , 10 , 1111100 , false));
            return null;
        }
    }

}
