package com.example.alarmclock.alarm;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface alarm_timeDao {

  @Insert
    void insert(alarm_time alarmTime);

  @Update
    void update(alarm_time alarmTime);

  @Delete
    void delete(alarm_time alarmTime);

  @Query("DELETE FROM alarm_table")
    void deleteAllAlarms();

  @Query("SELECT * FROM alarm_table ORDER BY Tid ASC")
  LiveData<List<alarm_time>> getAllAlarms();
}
