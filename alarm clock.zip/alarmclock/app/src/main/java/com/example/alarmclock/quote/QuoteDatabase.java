package com.example.alarmclock.quote;

import android.content.Context;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

@Database( entities = {Quote_saved.class} , version = 1)
public abstract class QuoteDatabase extends RoomDatabase {

    private static QuoteDatabase instance ;

    public abstract QuoteDao quoteDao();

    public static synchronized QuoteDatabase getInstance(Context context){
        if(instance== null){
            instance = Room.databaseBuilder(context.getApplicationContext(),
                    QuoteDatabase.class, "quote_database")
                    .fallbackToDestructiveMigration()
                    .addCallback(roomQuoteCallback)
                    .build();
        }
        return instance;
    }

    private static RoomDatabase.Callback roomQuoteCallback = new RoomDatabase.Callback() {
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
            new PopulateQuoteDbAsyncTask(instance).execute();
        }
    };

    private static class PopulateQuoteDbAsyncTask extends AsyncTask<Void , Void ,  Void > {
        private QuoteDao quoteDao;

        private PopulateQuoteDbAsyncTask(QuoteDatabase db) {
            quoteDao = db.quoteDao();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            quoteDao.insert(new Quote_saved("If you quit once, it becomes a habit. Keep going."));
            quoteDao.insert(new Quote_saved("You didn't come this far to only come this far."));
            quoteDao.insert(new Quote_saved("The trouble is you think you have time."));
            quoteDao.insert(new Quote_saved("Don't quit your daydreams."));
            return null;
        }

    }
}
