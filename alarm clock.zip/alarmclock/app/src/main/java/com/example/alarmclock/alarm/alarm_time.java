package com.example.alarmclock.alarm;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "alarm_table")
public class alarm_time {
    @PrimaryKey(autoGenerate = true)
    public int Tid;

    @ColumnInfo
    public int hour;

    @ColumnInfo
    public int minute;

    @ColumnInfo
    public int day;

    @ColumnInfo
    public boolean on;

    public alarm_time(int hour, int minute, int day, boolean on) {
        this.hour = hour;
        this.minute = minute;
        this.day = day;
        this.on = on;
    }
}
