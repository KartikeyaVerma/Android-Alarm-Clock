package com.example.alarmclock.alarm;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class AlarmService extends Service {
    BroadcastReceiver aReceiver;
    public class AlarmReceiver extends BroadcastReceiver{

        @Override
        public void onReceive(Context context, Intent intent) {
            Toast.makeText(context , "Alarm Ringing" , Toast.LENGTH_LONG).show();
            Intent intent1 = new Intent(context , AlarmAlert.class);
            intent1.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent1);
        }
        public AlarmReceiver(){

        }
    }

    @Override
    public void onCreate() {
        aReceiver = new AlertReceiver();
        IntentFilter filter = new IntentFilter();
        registerReceiver(aReceiver , filter);
        super.onCreate();
    }

    @Override
    public void onDestroy() {
        unregisterReceiver(aReceiver);
        aReceiver = null;
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
