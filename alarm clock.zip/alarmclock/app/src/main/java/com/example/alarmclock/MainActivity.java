package com.example.alarmclock;

import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.alarmclock.routine.RoutineFragment;
import com.example.alarmclock.alarm.AlarmFragment;
import com.example.alarmclock.quote.QuoteFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;


public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "onCreate: ");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BottomNavigationView navigationView_bottom = findViewById(R.id.bottom_navigation_bar);
        navigationView_bottom.setOnNavigationItemSelectedListener(navListener);
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container ,
                new AlarmFragment()).commit();
    }


    private BottomNavigationView.OnNavigationItemSelectedListener navListener =
          new BottomNavigationView.OnNavigationItemSelectedListener() {
              @Override
              public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                  Log.d(TAG, "onNavigationItemSelected: ");

                  Fragment selectedFragment = null ;

                  switch (item.getItemId()){
                      case R.id.nav_alarm:
                          selectedFragment = new AlarmFragment();
                          break;
                      case R.id.nav_quote:
                          selectedFragment = new QuoteFragment();
                          break;
                      case R.id.nav_routine:
                          selectedFragment = new RoutineFragment();
                          break;
                  }
                  getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container ,
                          selectedFragment).commit();
                  return true;
              }
          };
}