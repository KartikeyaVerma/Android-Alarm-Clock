package com.example.alarmclock.alarm;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;

public class AlarmRepository {

    private alarm_timeDao alarmTimeDao;
    private LiveData<List<alarm_time>> allAlarms;

    public AlarmRepository(Application application){
        AlarmDatabase alarmDatabase =  AlarmDatabase.getInstance(application);

        alarmTimeDao = alarmDatabase.alarmTimeDao();
        allAlarms = alarmTimeDao.getAllAlarms();
    }

    public void insert(alarm_time alarmTime){
        new InsertAlarmsAsyncTask(alarmTimeDao).execute(alarmTime);
    }
    public void update(alarm_time alarmTime){
        new UpdateAlarmsAsyncTask(alarmTimeDao).execute(alarmTime);
    }
    public void delete(alarm_time alarmTime){
        new DeleteAlarmsAsyncTask(alarmTimeDao).execute(alarmTime);
    }
    public void deleteAllAlarms(){
        new DeleteAllAlarmsAsyncTask(alarmTimeDao).execute();
    }
    public LiveData<List<alarm_time>> getAllAlarms(){
        return allAlarms ;
    }



    //AsyncTasks being called for the above respective functions
    private static class InsertAlarmsAsyncTask extends AsyncTask<alarm_time, Void , Void>{
        private alarm_timeDao alarmTimeDao ;
        private InsertAlarmsAsyncTask(alarm_timeDao alarmTimeDao){
            this.alarmTimeDao = alarmTimeDao;
        }

        @Override
        protected Void doInBackground(alarm_time... alarm_times) {
            alarmTimeDao.insert(alarm_times[0]);
            return null;
        }
    }

    private static class DeleteAlarmsAsyncTask extends AsyncTask<alarm_time, Void , Void>{
        private alarm_timeDao alarmTimeDao ;
        private DeleteAlarmsAsyncTask(alarm_timeDao alarmTimeDao){
            this.alarmTimeDao = alarmTimeDao;
        }

        @Override
        protected Void doInBackground(alarm_time... alarm_times) {
            alarmTimeDao.delete(alarm_times[0]);
            return null;
        }
    }

    private static class UpdateAlarmsAsyncTask extends AsyncTask<alarm_time, Void , Void>{
        private alarm_timeDao alarmTimeDao ;
        private UpdateAlarmsAsyncTask(alarm_timeDao alarmTimeDao){
            this.alarmTimeDao = alarmTimeDao;
        }

        @Override
        protected Void doInBackground(alarm_time... alarm_times) {
            alarmTimeDao.update(alarm_times[0]);
            return null;
        }
    }
    private static class DeleteAllAlarmsAsyncTask extends AsyncTask<Void, Void , Void>{
        private alarm_timeDao alarmTimeDao ;
        private DeleteAllAlarmsAsyncTask(alarm_timeDao alarmTimeDao){
            this.alarmTimeDao = alarmTimeDao;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            alarmTimeDao.deleteAllAlarms();
            return null;
        }
    }
}
