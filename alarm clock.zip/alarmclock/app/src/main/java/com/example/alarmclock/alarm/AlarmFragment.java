package com.example.alarmclock.alarm;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.TimePicker;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.alarmclock.R;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;


public class AlarmFragment extends Fragment implements View.OnClickListener {
    private static final String TAG = "AlarmFragment";
    private FloatingActionButton floatingActionButton;
    private AlarmViewModel alarmViewModel ;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        Log.d(TAG, "onCreateView: ");
        View view =inflater.inflate(R.layout.fragment_alarm , container , false);


        floatingActionButton=view.findViewById(R.id.alarm_fab);
        floatingActionButton.setOnClickListener(this);
        RecyclerView recyclerView = view.findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setHasFixedSize(false);

        final AlarmListAdapter adapter = new AlarmListAdapter(getContext());
        recyclerView.setAdapter(adapter);

        alarmViewModel = new ViewModelProvider(getActivity()).get(AlarmViewModel.class);
        alarmViewModel.getAllAlarms().observe(getActivity(), new Observer<List<alarm_time>>() {
            @Override
            public void onChanged(List<alarm_time> alarm_times) {
                //update RecyclerView
                adapter.setAlarms(alarm_times);
            }
        });

        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0 , ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                alarmViewModel.delete(adapter.getAlarmAt(viewHolder.getAdapterPosition()));
            }
        }).attachToRecyclerView(recyclerView);
        return view;
    }



    @Override
    public void onClick(View v) {
        Log.d(TAG, "onClick: alarm_fragment ");
        switch (v.getId()){

            case R.id.alarm_fab:
                final BottomSheetDialog mBottomSheetDialog = new BottomSheetDialog(getActivity() , R.style.BottomDialogTheme);
                View sheetView = getActivity().getLayoutInflater().inflate(R.layout.bottom_sheet_alarm, null);
                mBottomSheetDialog.setContentView(sheetView);
                mBottomSheetDialog.show();
                final View add_alarm = mBottomSheetDialog.findViewById(R.id.add_alarm);

                TimePicker alarm_timePicker = mBottomSheetDialog.findViewById(R.id.alarm_time_picker);
                alarm_timePicker.setIs24HourView(false);
                final Integer[] alarmDays = {1 , 1 , 1 , 1 , 1 , 1 , 1};

                final TextView Mo;
                final TextView Tu;
                final TextView We;
                final TextView Th;
                final TextView Fr;
                final TextView Sa;
                final TextView Su;
                Mo = mBottomSheetDialog.findViewById(R.id.mo);
                Tu = mBottomSheetDialog.findViewById(R.id.tu);
                We = mBottomSheetDialog.findViewById(R.id.we);
                Th = mBottomSheetDialog.findViewById(R.id.th);
                Fr = mBottomSheetDialog.findViewById(R.id.fr);
                Sa = mBottomSheetDialog.findViewById(R.id.sa);
                Su = mBottomSheetDialog.findViewById(R.id.su);
                Mo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (alarmDays[0]==0){
                           alarmDays[0]=1;
                           Mo.setTextColor(Color.parseColor("#13A6A9"));

                        }
                        else{
                            alarmDays[0]=0;
                            Mo.setTextColor(Color.parseColor("#A91362"));
                        }

                    }
                });
                Tu.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (alarmDays[1]==0){
                            alarmDays[1]=1;
                            Tu.setTextColor(Color.parseColor("#13A6A9"));
                        }
                        else{
                            alarmDays[1]=0;
                            Tu.setTextColor(Color.parseColor("#A91362"));
                        }
                    }
                });
                We.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (alarmDays[2]==0){
                            alarmDays[2]=1;
                            We.setTextColor(Color.parseColor("#13A6A9"));
                        }
                        else{
                            alarmDays[2]=0;
                            We.setTextColor(Color.parseColor("#A91362"));
                        }
                    }
                });
                Th.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (alarmDays[3]==0){
                            alarmDays[3]=1;
                            Th.setTextColor(Color.parseColor("#13A6A9"));
                        }
                        else{
                            alarmDays[3]=0;
                            Th.setTextColor(Color.parseColor("#A91362"));
                        }
                    }
                });
                Fr.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (alarmDays[4]==0){
                            alarmDays[4]=1;
                            Fr.setTextColor(Color.parseColor("#13A6A9"));
                        }
                        else{
                            alarmDays[4]=0;
                            Fr.setTextColor(Color.parseColor("#A91362"));
                        }
                    }
                });
                Sa.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (alarmDays[5]==0){
                            alarmDays[5]=1;
                            Sa.setTextColor(Color.parseColor("#13A6A9"));
                        }
                        else{
                            alarmDays[5]=0;
                            Sa.setTextColor(Color.parseColor("#A91362"));
                        }
                    }
                });
                Su.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (alarmDays[6]==0){
                            alarmDays[6]=1;
                            Su.setTextColor(Color.parseColor("#13A6A9"));
                        }
                        else{
                            alarmDays[6]=0;
                            Su.setTextColor(Color.parseColor("#A91362"));
                        }
                    }
                });

                alarm_timePicker.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
                    @Override
                    public void onTimeChanged(TimePicker view, final int hourOfDay, final int minute) {
                        int d = 0 ;

                        for(int i = 6 ; i>=0 ; i--){
                            d=d+alarmDays[i];
                            d = d*10;
                        }
                        d=d/10;
                        final int finalD = d;

                        add_alarm.setOnClickListener(new View.OnClickListener() {
                            @Override

                            public void onClick(View v) {
                                Log.d(TAG, "onClick: create_alarm ");
                                alarm_time AlarmTime = new alarm_time(hourOfDay , minute , finalD, true);
                                alarmViewModel.insert(AlarmTime);
                                mBottomSheetDialog.hide();

                            }
                        });
                    }
                });

                break;

        }

    }

}
