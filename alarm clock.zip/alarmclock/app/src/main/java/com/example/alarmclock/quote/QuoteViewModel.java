package com.example.alarmclock.quote;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class QuoteViewModel extends AndroidViewModel {

    private QuoteRepository Quoterepository;
    private LiveData<List<Quote_saved>> allQuotes;

    public QuoteViewModel(@NonNull Application application) {
        super(application);
        Quoterepository = new QuoteRepository(application);
        allQuotes = Quoterepository.getAllQuotes();
    }

    public void insert(Quote_saved quote_saved) {
        Quoterepository.insert(quote_saved);
    }

    public void delete(Quote_saved quote_saved) {
        Quoterepository.delete(quote_saved);
    }

    public void update(Quote_saved quote_saved) {
        Quoterepository.update(quote_saved);
    }

    public void deleteAllQuotes() {
        Quoterepository.deleteAllQuotes();
    }

    public LiveData<List<Quote_saved>> getAllQuotes() {
        return allQuotes;
    }
}

