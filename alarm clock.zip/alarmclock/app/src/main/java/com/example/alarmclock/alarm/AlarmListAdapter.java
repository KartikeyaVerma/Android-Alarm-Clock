package com.example.alarmclock.alarm;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.alarmclock.R;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class AlarmListAdapter extends RecyclerView.Adapter<AlarmListAdapter.AlarmHolder> {
    private static final String TAG = "AlarmListAdapter";
    private List<alarm_time> alarms = new ArrayList<>();
    private final Context mContext;

    public AlarmListAdapter(Context context){
        mContext = context ;
    }
    @NonNull
    @Override
    public AlarmHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.new_alarm , parent , false);
        return new AlarmHolder(itemView, new MyClickListener() {
            @Override
            public void alarmTurnsOn(int p) {
                startAlarm(p);
            }

            @Override
            public void alarmTurnsOff(int p) {
                cancelAlarm(p);
            }
        });
    }

    private void startAlarm(int p) {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY , alarms.get(p).hour);
        c.set(Calendar.MINUTE , alarms.get(p).minute);
        c.set(Calendar.SECOND , 0);

        AlarmManager alarmManager = (AlarmManager)mContext.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(mContext, AlertReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(mContext , alarms.get(p).Tid , intent , 0);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP , c.getTimeInMillis() , pendingIntent);
        }
    }

    private void cancelAlarm(int p) {
        AlarmManager alarmManager = (AlarmManager)mContext.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(mContext, AlertReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(mContext , alarms.get(p).Tid , intent , 0);

        alarmManager.cancel(pendingIntent);
    }

    //where we manages taking data from java object and into the AlarmHolder

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull AlarmHolder holder, int position) {
        alarm_time currentAlarmTime = alarms.get(position);
        int h;
        final Integer[] alarmDays = {1 , 1 , 1 , 1 , 1 , 1 , 1};
        int d = alarms.get(position).day;
        for(int i = 0 ; i<7 ; i++){
            alarmDays[i] = d%10;
            d = d/10;
        }

        //changing color of the alarm days
        if (alarmDays[0]==1){
            holder.mo.setTextColor(Color.parseColor("#13A6A9"));
        }
        else{
            holder.mo.setTextColor(Color.parseColor("#A91362"));
        }
        if (alarmDays[1]==1){
            holder.tu.setTextColor(Color.parseColor("#13A6A9"));
        }
        else{
            holder.tu.setTextColor(Color.parseColor("#A91362"));
        }
        if (alarmDays[2]==1){
            holder.we.setTextColor(Color.parseColor("#13A6A9"));
        }
        else{
            holder.we.setTextColor(Color.parseColor("#A91362"));
        }
        if (alarmDays[3]==1){
            holder.th.setTextColor(Color.parseColor("#13A6A9"));
        }
        else{
            holder.th.setTextColor(Color.parseColor("#A91362"));
        }
        if (alarmDays[4]==1){
            holder.fr.setTextColor(Color.parseColor("#13A6A9"));
        }
        else{
            holder.fr.setTextColor(Color.parseColor("#A91362"));
        }
        if (alarmDays[5]==1){
            holder.sa.setTextColor(Color.parseColor("#13A6A9"));
        }
        else{
            holder.sa.setTextColor(Color.parseColor("#A91362"));
        }
        if (alarmDays[6]==1){
            holder.su.setTextColor(Color.parseColor("#13A6A9"));
        }
        else{
            holder.su.setTextColor(Color.parseColor("#A91362"));
        }

        //displaying am-pm
        if(currentAlarmTime.hour<=12){
            holder.am_pm_display.setText("am");
            h=currentAlarmTime.hour;
        }
        else{
            holder.am_pm_display.setText("pm");
            h=currentAlarmTime.hour - 12;
        }

        //displaying time
        holder.time.setText( h + ":" + currentAlarmTime.minute);
    }

    @Override
    public int getItemCount() {
        return alarms.size();
    }

    public void setAlarms(List<alarm_time> alarm_times){
        this.alarms = alarm_times;
        notifyDataSetChanged();
    }

    public alarm_time getAlarmAt(int position){
        return alarms.get(position);
    }

    static class AlarmHolder extends RecyclerView.ViewHolder{

        MyClickListener listener;

        private final TextView time;
        private final TextView am_pm_display;
        private final TextView mo;
        private final TextView tu;
        private final TextView we;
        private final TextView th;
        private final TextView fr;
        private final TextView sa;
        private final TextView su;
        @SuppressLint("UseSwitchCompatOrMaterialCode")
        private final Switch alarmOnOff;

        public AlarmHolder(View itemView , final MyClickListener listener){
            super(itemView);
            time = itemView.findViewById(R.id.time_display);
            am_pm_display=itemView.findViewById(R.id.am_pm_display);
            mo=itemView.findViewById(R.id.monday);
            tu=itemView.findViewById(R.id.tuesday);
            we=itemView.findViewById(R.id.wednesday);
            th=itemView.findViewById(R.id.thursday);
            fr=itemView.findViewById(R.id.friday);
            sa=itemView.findViewById(R.id.saturday);
            su=itemView.findViewById(R.id.sunday);
            alarmOnOff = itemView.findViewById(R.id.alarmToggle);

            this.listener = listener;

            alarmOnOff.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked){
                        //Alarm turned ON
                        listener.alarmTurnsOn(getLayoutPosition());
                    }
                    else{
                        //Alarm turned OFF
                        listener.alarmTurnsOff(getLayoutPosition());
                    }
                }
            });
        }
    }
    public interface MyClickListener {
        void alarmTurnsOn(int p);
        void alarmTurnsOff(int p);
    }
}
