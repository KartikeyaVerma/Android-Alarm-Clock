package com.example.alarmclock.quote;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.alarmclock.R;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class QuoteFragment extends Fragment implements View.OnClickListener {
    private static final String TAG = "QuoteFragment";
    private QuoteViewModel quoteViewModel;
    private FloatingActionButton quoteFAB;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        Log.d(TAG, "onCreateView: ");
        View view =inflater.inflate(R.layout.fragment_quote , container , false);

        quoteFAB = view.findViewById(R.id.quote_fab);
        quoteFAB.setOnClickListener(this);


        RecyclerView quoteRecyclerView = view.findViewById(R.id.quote_recyclerview);
        quoteRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        quoteRecyclerView.setHasFixedSize(false);

        final QuoteAdapter quoteAdapter = new QuoteAdapter();
        quoteRecyclerView.setAdapter(quoteAdapter);

       quoteViewModel = new ViewModelProvider(getActivity()).get(QuoteViewModel.class);
       quoteViewModel.getAllQuotes().observe(getActivity(), new Observer<List<Quote_saved>>() {
           @Override
           public void onChanged(List<Quote_saved> quotes) {
               quoteAdapter.setQuotes(quotes);
           }
       });

       new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0 ,
               ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
           @Override
           public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
               return false;
           }

           @Override
           public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                quoteViewModel.delete(quoteAdapter.getQuoteAt(viewHolder.getAdapterPosition()));
           }
       }).attachToRecyclerView(quoteRecyclerView);

       /*
        quoteFAB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
          *//*    Quote_saved quote = new Quote_saved("Don't quit your daydreams.");
                quoteViewModel.insert(quote);*//*
                final BottomSheetDialog qBottomSheetDialog = new BottomSheetDialog(getActivity() , R.style.BottomDialogTheme);
                View quoteSheet = getActivity().getLayoutInflater().inflate(R.layout.bottom_sheet_quote ,  null);
                qBottomSheetDialog.setContentView(quoteSheet);
                qBottomSheetDialog.show();
               *//* quoteViewModel.insert(new Quote_saved("Empty Quote Template"));
                qBottomSheetDialog.hide();*//*

                final EditText quoteInput ;
                final TextView createQuote ;

                quoteInput = qBottomSheetDialog.findViewById(R.id.quote_text);
                createQuote= qBottomSheetDialog.findViewById(R.id.add_quote);

                final String quote = String.valueOf(quoteInput.getText());

                createQuote.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        Quote_saved temp = new Quote_saved(quote);
                        quoteViewModel.insert(temp);
                        qBottomSheetDialog.hide();
                    }
                });
            }
        });*/
        return view;
    }

    @Override
    public void onClick(View v) {

        final BottomSheetDialog qBottomSheetDialog = new BottomSheetDialog(getActivity() , R.style.BottomDialogTheme);
        View quoteSheet = getActivity().getLayoutInflater().inflate(R.layout.bottom_sheet_quote ,  null);
        qBottomSheetDialog.setContentView(quoteSheet);
        qBottomSheetDialog.show();

        final EditText quoteInput ;
        final TextView createQuote ;

        quoteInput = qBottomSheetDialog.findViewById(R.id.quoteInput);
        createQuote= qBottomSheetDialog.findViewById(R.id.add_quote);

     /*   final String quote = String.valueOf(quoteInput.getText());*/

        createQuote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Quote_saved temp = null;
                if (quoteInput != null) {
                    temp = new Quote_saved(String.valueOf(quoteInput.getText()));
                }
                quoteViewModel.insert(temp);
                qBottomSheetDialog.hide();
            }
        });
    }

}
