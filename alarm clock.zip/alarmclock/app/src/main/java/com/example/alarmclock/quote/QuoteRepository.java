package com.example.alarmclock.quote;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;

public class QuoteRepository {
    private QuoteDao quoteDao;
    private LiveData<List<Quote_saved>> allQuotes;

    public QuoteRepository(Application application) {
        QuoteDatabase quoteDatabase = QuoteDatabase.getInstance(application);
        quoteDao = quoteDatabase.quoteDao();
        allQuotes=quoteDao.getAllQuotes();
    }

    public void insert(Quote_saved quote_saved) {
        new InsertQuoteAsyncTask(quoteDao).execute(quote_saved);
    }

    public void update (Quote_saved quote_saved) {
        new UpdateQuoteAsyncTask(quoteDao).execute(quote_saved);
    }

    public void delete (Quote_saved quote_saved) {
        new DeleteQuoteAsyncTask(quoteDao).execute(quote_saved);
    }

    public void deleteAllQuotes() {
        new DeleteAllQuoteAsyncTask(quoteDao).execute();
    }

    public LiveData<List<Quote_saved>> getAllQuotes() {
        return allQuotes;
    }

    private static class InsertQuoteAsyncTask extends AsyncTask<Quote_saved, Void , Void > {
        private QuoteDao quoteDao;

        private InsertQuoteAsyncTask(QuoteDao quoteDao) {
            this.quoteDao = quoteDao;
        }

        @Override
        protected Void doInBackground(Quote_saved... quote_saveds) {
            quoteDao.insert(quote_saveds[0]);
            return null;
        }
    }


    private static class DeleteAllQuoteAsyncTask extends AsyncTask<Void , Void , Void > {
        private QuoteDao quoteDao;

        private DeleteAllQuoteAsyncTask(QuoteDao quoteDao) {
            this.quoteDao = quoteDao;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            quoteDao.delete_all_quotes();
            return null;
        }
    }

    private static class UpdateQuoteAsyncTask extends AsyncTask<Quote_saved, Void , Void > {
        private QuoteDao quoteDao;

        private UpdateQuoteAsyncTask(QuoteDao quoteDao) {
            this.quoteDao = quoteDao;
        }

        @Override
        protected Void doInBackground(Quote_saved... quote_saveds) {
            quoteDao.update(quote_saveds[0]);
            return null;
        }
    }

    private static class DeleteQuoteAsyncTask extends AsyncTask<Quote_saved, Void , Void > {
        private QuoteDao quoteDao;

        private DeleteQuoteAsyncTask(QuoteDao quoteDao) {
            this.quoteDao = quoteDao;
        }

        @Override
        protected Void doInBackground(Quote_saved... quote_saveds) {
            quoteDao.delete(quote_saveds[0]);
            return null;
        }
    }
}
