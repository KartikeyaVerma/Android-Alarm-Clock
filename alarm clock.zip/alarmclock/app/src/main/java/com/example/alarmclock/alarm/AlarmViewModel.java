package com.example.alarmclock.alarm;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
;import java.util.List;

public class AlarmViewModel extends AndroidViewModel {
    private AlarmRepository repository;
    private LiveData<List<alarm_time>> allAlarms;


    public AlarmViewModel (@NonNull Application application) {
        super(application);
        repository = new AlarmRepository(application);
        allAlarms = repository.getAllAlarms();
    }


    public void insert(alarm_time alarmTime){
        repository.insert(alarmTime);
    }
    public void delete(alarm_time alarmTime){
        repository.delete(alarmTime);
    }
    public void update(alarm_time alarmTime){
        repository.update(alarmTime);
    }
    public void deleteAllAlarms(){
        repository.deleteAllAlarms();
    }
    public LiveData<List<alarm_time>> getAllAlarms(){
        return allAlarms;
    }
}
