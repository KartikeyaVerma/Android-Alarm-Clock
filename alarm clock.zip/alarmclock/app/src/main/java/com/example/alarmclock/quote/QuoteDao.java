package com.example.alarmclock.quote;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface QuoteDao {

    @Insert
    void insert(Quote_saved quote_saved);

    @Update
    void update(Quote_saved quote_saved);

    @Delete
    void delete(Quote_saved quote_saved);

    @Query("DELETE FROM quote_table")
    void delete_all_quotes();

    @Query("SELECT * FROM quote_table ORDER BY id ASC")
    LiveData<List<Quote_saved>> getAllQuotes();
}
